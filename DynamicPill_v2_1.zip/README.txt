Dynamic Pill (LSPosed module) v2.1
1. Upload this zip's contents to a GitHub repo (the .github/workflows/build.yml is included).
2. Actions tab -> Build APK -> download artifact DynamicPill-apk.
3. Install the APK, LSPosed -> Modules -> enable "Dynamic Pill" -> scope: System UI.
4. Reboot. Open settings from the "Dynamic Pill" Control Center tile (long press) or from LSPosed.

Changes in 2.1
- Status bar height / padding rebuilt with the System UI classes used by CustoMIUIzer
  (StatusBarContentInsetsProvider, KeyguardStatusBarView, status_bar_height_* resources).
- Settings screen follows the system light / dark mode.
- New iOS style sliders and switches; extra heading texts removed.
